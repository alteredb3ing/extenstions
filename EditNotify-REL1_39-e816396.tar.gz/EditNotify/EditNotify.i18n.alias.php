<?php
/**
 * Aliases for special pages of the Editnotify extension
 *
 * @file
 * @ingroup Extensions
 */

$specialPageAliases = [];

/** English (English) */
$specialPageAliases['en'] = [
	'EditNotify' => [ 'EditNotify' ],
];
