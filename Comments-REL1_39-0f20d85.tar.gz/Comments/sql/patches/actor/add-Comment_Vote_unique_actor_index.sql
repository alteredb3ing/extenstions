CREATE UNIQUE INDEX /*i*/Comments_Vote_actor_index ON /*_*/Comments_Vote (Comment_Vote_ID,Comment_Vote_actor);
