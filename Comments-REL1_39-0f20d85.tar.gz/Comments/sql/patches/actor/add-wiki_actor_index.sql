CREATE INDEX /*i*/wiki_actor ON /*_*/Comments (Comment_actor);
