ALTER TABLE /*_*/Comments DROP COLUMN Comment_user_id;
