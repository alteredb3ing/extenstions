ALTER TABLE /*_*/Comments_block ADD COLUMN cb_actor bigint unsigned NOT NULL AFTER cb_id;
