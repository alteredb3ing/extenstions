-- Patch to drop unused event_page_namespace
alter table /*_*/echo_event drop event_page_namespace;

