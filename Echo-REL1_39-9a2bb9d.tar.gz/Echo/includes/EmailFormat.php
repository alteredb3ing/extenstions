<?php

class EchoEmailFormat {
	public const HTML = 'html';
	public const PLAIN_TEXT = 'plain-text';
}
