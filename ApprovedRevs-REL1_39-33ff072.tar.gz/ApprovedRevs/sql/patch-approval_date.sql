ALTER TABLE /*_*/approved_revs
  ADD COLUMN approval_date timestamp NULL;
