<?php
/**
 *  Magic words for extension.
 */

$magicWords = [];

/** English (English) */
$magicWords['en'] = [
	'cscore' => [ 0, 'cscore' ],
];
